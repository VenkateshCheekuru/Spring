package com.tcs.anz;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
@Component
public class Circle implements Shape,ApplicationEventPublisherAware{
	private Point center;
	private ApplicationEventPublisher publisher;
	private MessageSource messageSource;
	public MessageSource getMessageSource() {
		return messageSource;
	}
	@Autowired
	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}
	public Point getCenter() {
		return center;
	}
	@Resource(name="pointC")
	public void setCenter(Point center) {
		this.center = center;
	}
	@Override
	public void draw() {
		System.out.println(messageSource.getMessage("drawing.circle", null,"Default draw circle",null));
		System.out.println(messageSource.getMessage("drawing.point", new Object[]{center.getX(),center.getY()},"Default Draw Point", null));
		
		MyEvent event=new MyEvent(this);
		publisher.publishEvent(event);
	}
	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
		this.publisher=applicationEventPublisher;
		
	}

	
	
}
