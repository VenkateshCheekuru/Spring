package com.tcs.anz;

import org.springframework.context.ApplicationEvent;

public class MyEvent extends ApplicationEvent{

	public MyEvent(Object source) {
		super(source);
		
	}
	public String toString()
	{
		return "Draw Event occured." ;
	}

}
