package com.tcs.anz;

public interface Shape {
	public void draw();

}
