package SpringApplicationContext;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringAppRun {

	public static void main(String[] args) {
	
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		System.out.println("Triangle 1 points:");
		Triangle triangle1 = (Triangle) context.getBean("triangle2");
		triangle1.display();
		
		System.out.println("Triangle 2 points:");
		Triangle triangle = (Triangle) context.getBean("triangle3");
		triangle.display();
		
		
	}

}
                                                  