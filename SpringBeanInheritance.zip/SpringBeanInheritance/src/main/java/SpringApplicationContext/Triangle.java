package SpringApplicationContext;

import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import java.util.ArrayList;

public class Triangle implements ApplicationContextAware, BeanNameAware {
	/*private Point pointA;
	private Point pointB;*/
	private ApplicationContext context;
	private String beanName;

	
	private List <Point> points;
	public void draw()
	{
		
		points.forEach(p->System.out.println("Point ("+p.getX()+","+p.getY()+")"));
	}

	public List<Point> getPoints() {
		return points;
	}

	public void setPoints(List<Point> points) {
		this.points = points;
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {

		context=applicationContext;
	}

	@Override
	public void setBeanName(String name) {
		beanName=name;
		
	}
	public void display()
	{
		Triangle triangle=(Triangle)context.getBean(beanName);
		triangle.draw();
	}

}
