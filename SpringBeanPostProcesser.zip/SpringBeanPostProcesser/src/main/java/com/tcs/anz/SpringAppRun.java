package com.tcs.anz;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringAppRun {

	public static void main(String[] args) {
	
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Triangle triangle1 = (Triangle) context.getBean("parent-triangle1");
		triangle1.draw();
		context.registerShutdownHook();
		
	}

}
