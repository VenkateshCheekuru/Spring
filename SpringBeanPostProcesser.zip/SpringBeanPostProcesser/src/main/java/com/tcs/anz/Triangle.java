package com.tcs.anz;

import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import java.util.ArrayList;

public class Triangle implements InitializingBean,DisposableBean {

	private ApplicationContext context;
	private String beanName;

	
	private List <Point> points;
	public void draw()
	{
		
		points.forEach(p->System.out.println("Point ("+p.getX()+","+p.getY()+")"));
	}

	public List<Point> getPoints() {
		return points;
	}

	public void setPoints(List<Point> points) {
		this.points = points;
	}	
	public void myInit()
	{
		System.out.println("My init method called for class Triangle");
	}
	
	public void cleanUp()
	{
		System.out.println("My cleanUp method called for class Triangle");
	}
	
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("InitializingBean init method called for class Triangle");
	}


	@Override
	public void destroy() throws Exception {
		System.out.println("DisposableBean destroy method called for class Triangle");
		
	}

	
}
