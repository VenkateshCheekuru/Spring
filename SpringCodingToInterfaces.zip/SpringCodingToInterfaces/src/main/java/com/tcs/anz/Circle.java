package com.tcs.anz;

public class Circle implements Shape {
	private Point center;
	private int radius;

	public Point getCenter() {
		return center;
	}

	public void setCenter(Point center) {
		this.center = center;
	}

	@Override
	public void draw() {
		System.out.println("Circle drawn:");
		System.out.println("Center is (" + getCenter().getX() + ","
				+ getCenter().getY() + ")");
		System.out.println("Radius is " + getRadius());
	}

	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}

}
