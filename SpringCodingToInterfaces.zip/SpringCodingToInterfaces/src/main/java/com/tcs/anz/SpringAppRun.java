package com.tcs.anz;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringAppRun {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext(
				"spring.xml");
		Shape shape = (Triangle) context.getBean("parent-triangle1");
		shape.draw();
		
		
		Shape shape1 = (Circle) context.getBean("circle");
		shape1.draw();
		
		
	
	}

}
