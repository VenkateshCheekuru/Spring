package SpringApplicationContext;

public class Triangle {
	private String Type;
	private int height;
	private double breadth;
	//Using Constructor to set height value
	public Triangle(int height)
	{
		this.height=height;
	}
	public Triangle(double breadth)
	{
		this.breadth=breadth;
	}
	public Triangle(int height,double breadth)
	{
		this.height=height;
		this.breadth=breadth;
	}
	public double getBreadth()
	{
		return breadth;
	}
	public int getHeight() {
		return height;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	public void draw()
	{
		System.out.print(getType()+" Triangle drawn at a height of "+getHeight() +" and breadth of "+getBreadth());
	}

}
